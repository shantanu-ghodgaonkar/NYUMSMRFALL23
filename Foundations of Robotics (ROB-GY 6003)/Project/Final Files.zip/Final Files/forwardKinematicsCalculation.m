function result = forwardKinematicsCalculation(angles)
    result = MakeTransformOfEEinB(angles);
end